const Colors ={
    accent300: "rgb(122, 160, 122)",
    accent500: "rgb(47, 93, 58)",
    primary300o5: "rgba(247, 241, 227, 0.5)",
    primary300: "rgb(247, 241, 227)",
    primary500: "rgb(231, 111, 81)",
    primary800: "rgb(75, 54, 33)",
  };
  
  export default Colors;
  