const Colors ={
    accent500: "#b9a1cc",
    accent800: "#a7c7a2",
    primary300: "#ffffff",
    primary500: "#d9b45c",
    primary800: "#355E3B",
};

export default Colors;