const Colors ={
    accent500: "#E20031",
    primary500: "#d9d9d9",
}

export default Colors;