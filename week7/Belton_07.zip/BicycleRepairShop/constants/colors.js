
const Colors = {
    accent500: "#0B1F2A",
    accent800: "#07151D",
    primary500: "#FF6B00",
    primary300: "#F2F6F8",
    primary800: "#1F2937",
  };
  
  export default Colors;